// Vercel Serverless Function: POST /api/ai
const MAX_CHARS = 80000;
const buckets = new Map(); // rate limit sederhana per IP (best effort)
function limited(ip) {
  const now = Date.now(), win = 60000, max = 20;
  const arr = (buckets.get(ip) || []).filter(t => now - t < win);
  arr.push(now); buckets.set(ip, arr);
  return arr.length > max;
}
function clean(body) {
  const msgs = Array.isArray(body && body.messages) ? body.messages : null;
  if (!msgs || !msgs.length) return null;
  const out = msgs.slice(-20).map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '') }));
  if (out[0].role !== 'user') out.shift();
  const total = out.reduce((n, m) => n + m.content.length, 0);
  return out.length && total <= MAX_CHARS ? out : null;
}
async function askClaude(messages) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.CLAUDE_MODEL || 'claude-sonnet-5-5', max_tokens: 4000, messages })
  });
  const d = await r.json();
  if (!r.ok) throw new Error((d.error && d.error.message) || 'Permintaan ke Claude gagal');
  return { text: (d.content || []).map(c => c.text || '').join(''), truncated: d.stop_reason === 'max_tokens' };
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Gunakan POST' });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: 'ANTHROPIC_API_KEY belum diatur di server.' });
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0] || 'x';
  if (limited(ip)) return res.status(429).json({ error: 'Terlalu banyak permintaan. Coba lagi sebentar.' });
  const messages = clean(req.body);
  if (!messages) return res.status(400).json({ error: 'Format pesan tidak valid atau terlalu panjang.' });
  try { res.status(200).json(await askClaude(messages)); }
  catch (e) { res.status(502).json({ error: e.message }); }
};
